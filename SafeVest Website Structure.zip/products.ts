export const products = [
  {
    slug: 'smart-vest',
    name: 'Smart Safety Vest',
    description: 'AI-powered vest with fall detection, GPS tracking, and hazard alerts.',
    features: [
      'Fall detection',
      'GPS tracking',
      'Heat stress detection',
      'SOS emergency button',
      'AI hazard alerts'
    ],
    specifications: {
      sensors: [
        'Accelerometer',
        'Temperature sensor',
        'GPS module',
        'Motion sensor'
      ]
    },
    priceINR: 5999,
    image: '/images/vest.jpg'
  },
  {
    slug: 'smart-helmet',
    name: 'Smart Safety Helmet',
    description: 'Helmet with environmental sensors and real-time alerts.',
    features: [
      'Impact detection',
      'Gas sensors',
      'Helmet-off alerts',
      'AI safety analytics'
    ],
    specifications: {
      sensors: [
        'Impact sensor',
        'Gas sensor',
        'Bluetooth module'
      ]
    },
    priceINR: 7999,
    image: '/images/helmet.jpg'
  },
  // Add wristband, sensors, etc
]