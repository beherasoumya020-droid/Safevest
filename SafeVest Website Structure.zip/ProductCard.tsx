import Link from 'next/link'

export default function ProductCard({ product }) {
  return (
    <div className="product-card">
      <img src={product.image} alt={product.name} width={200} />
      <h3>{product.name}</h3>
      <p>{product.description}</p>
      <ul>
        {product.features.map(f => <li key={f}>{f}</li>)}
      </ul>
      <strong>Price: ₹{product.priceINR.toLocaleString('en-IN')}</strong>
      <Link href={`/products/${product.slug}`}>View Details</Link>
    </div>
  )
}