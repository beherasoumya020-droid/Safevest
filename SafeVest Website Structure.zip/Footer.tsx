export default function Footer() {
  return (
    <footer>
      <div>
        <h4>Product</h4>
        <ul>
          <li>Smart Safety Vest</li>
          <li>Smart Helmet</li>
          <li>Sensors</li>
        </ul>
      </div>
      <div>
        <h4>Platform</h4>
        <ul>
          <li>AI Safety Platform</li>
          <li>Worker Monitoring</li>
        </ul>
      </div>
      <div>
        <h4>Industries</h4>
        <ul>
          <li>Construction</li>
          <li>Mining</li>
          <li>Manufacturing</li>
        </ul>
      </div>
      <div>
        <h4>Company</h4>
        <ul>
          <li>About</li>
          <li>Careers</li>
          <li>Contact</li>
        </ul>
      </div>
      <div>
        <h4>Resources</h4>
        <ul>
          <li>Blog</li>
          <li>Whitepapers</li>
          <li>Case Studies</li>
        </ul>
      </div>
      <div>
        <strong>© {new Date().getFullYear()} SafeVest</strong>
      </div>
    </footer>
  )
}