import HeroSection from '../components/HeroSection'
import ProductCard from '../components/ProductCard'
import DashboardPreview from '../components/DashboardPreview'
import Testimonial from '../components/Testimonial'
import Navbar from '../components/Navbar'
import Footer from '../components/Footer'
import { products } from '../data/products'
import { testimonials } from '../data/testimonials'

export default function Home() {
  return (
    <>
      <Navbar />
      <HeroSection
        headline="AI-Powered Smart Safety for the Modern Workforce"
        subtext="Smart safety gear powered by IoT and AI that protects workers, predicts risks, and alerts supervisors in real time."
        heroImages={["/images/vest.jpg", "/images/dashboard.jpg"]}
        buttons={[
          { label: "Explore Products", href: "/products" },
          { label: "Request Demo", href: "/contact" }
        ]}
      />
      {/* Problem Section */}
      <section>
        <h2>Workplace Safety is Broken</h2>
        <p>Every year, thousands of construction workers suffer avoidable accidents. Only 44% of industrial sites pass safety compliance on the first audit.</p>
        {/* Add statistics visual (bar charts, etc) */}
      </section>
      {/* Solution Section */}
      <section>
        <h2>Smart Safety Ecosystem</h2>
        <div>
          <p>Smart Safety Gear | AI Safety Monitoring | Real-Time Worker Tracking</p>
        </div>
      </section>
      {/* Product Highlights */}
      <section>
        <h2>SafeVest Products</h2>
        <div style={{ display: 'flex', gap: 16 }}>
          {products.map(product => (
            <ProductCard key={product.slug} product={product} />
          ))}
        </div>
      </section>
      {/* Dashboard Preview */}
      <DashboardPreview images={["/images/dashboard.jpg"]} />
      {/* Industries Served */}
      <section>
        <h2>Industries Served</h2>
        <ul>
          <li>Construction</li>
          <li>Mining</li>
          <li>Manufacturing</li>
          <li>Oil & Gas</li>
          <li>Warehousing</li>
        </ul>
      </section>
      {/* Customer Testimonials */}
      <section>
        <h2>What Our Customers Say</h2>
        {testimonials.map((t, idx) => <Testimonial key={idx} testimonial={t} />)}
      </section>
      {/* CTA Section */}
      <section style={{ textAlign: 'center' }}>
        <h2>Transform Workplace Safety Today</h2>
        <button>Book Demo</button>
        <button>Start Free Trial</button>
      </section>
      <Footer />
    </>
  )
}